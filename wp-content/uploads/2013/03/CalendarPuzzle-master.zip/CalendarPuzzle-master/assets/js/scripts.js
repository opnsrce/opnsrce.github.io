function layOutDay(events) {
    var calendarDay = new CalendarDay(events);
}
$(document).ready(function() {
    layOutDay([{
        start: 30, // 9:30 AM
        end: 150 // 11:30 AM
    },
    {
        start: 540, // 6:00 PM -- OVERLAPS
        end: 600 // 7 PM
    },
    {
        start: 560, // 6:20 PM -- OVERLAPS
        end: 620 // 7:20 PM
    },
    {
        start: 610, // 7:10 PM -- OVERLAPS
        end: 670 // 8:10 PM
    }]);
});