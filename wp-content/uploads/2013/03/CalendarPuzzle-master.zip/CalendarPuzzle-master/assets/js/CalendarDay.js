var CalendarDay = (function ($) {
    'use strict';

    var C,
        convertTimeStringToDate,
        convertMinutesToHoursAndMinutes,
        eventTemplate,
        generateEvent,
        numEvents = 0,
        calculateEventPosition,
        doElementsOverlap,
        fullWidth,
        resizeEvents;

    eventTemplate = '<div class = "event" id = "event-{{eventId}}" data-start-time = "{{startTime}}" data-end-time = "{{endTime}}"> \
            <div class = "title">Sample Item</div> \
            <div class ="location">Sample Location</div> \
        </div>';


    resizeEvents = function(newEvent, events) {
        var overlappingEvents = [],
            numEvents,
            i = 0,
            numOverlappingEvents,
            newWidth,
            foundOverlappingEvents = false;

        newEvent = $(newEvent);
        events = $(events);
        if(events === undefined || events.length === 0) {
            events = $('#event_list div.event').not(newEvent[0]);
        }

        numEvents = events.length;

        for(i = 0; i <= numEvents - 1; i++) {
            if(doElementsOverlap(newEvent, $(events[i])) === true) {
                overlappingEvents.push($(events[i]));
                foundOverlappingEvents = true;
            }
            if(foundOverlappingEvents === true) {
                overlappingEvents.push(newEvent);
            }
        }
        numOverlappingEvents = overlappingEvents.length;

        if(numOverlappingEvents > 0) {
            for(i = 0; i <= numOverlappingEvents - 1; i++) {
                newWidth = Math.floor(97 / numOverlappingEvents);
                overlappingEvents[i].css({
                    width: newWidth + '%',
                    position: 'relative'
                });
            }
            newEvent.css({
                width: newWidth + '%',
                position: 'relative'
            });
        }

    };
    doElementsOverlap = function(element1, element2) {
        var element1Position = element1.position(),
            element1Left = element1Position.left,
            element1Right = element1Left + element1.outerWidth(),
            element1Top = element1Position.top,
            element1Bottom = element1Position.top + element1.outerHeight(),
            element2Position = element2.position(),
            element2Left = element2Position.left,
            element2Right = element2Left + element2.outerWidth(),
            element2Top = element2Position.top,
            element2Bottom = element2Position.top + element2.outerHeight(),
            overlap = false;

        if(element2Left>element1Right || element2Right<element1Left){
            return false;
        }
        if(element2Top>element1Bottom || element2Bottom<element1Top){
            return false;
        }

        if(element2Left>element1Left && element2Left<element1Right){
            return true;
        }
        if(element2Right>element1Left && element2Right<element1Right){
            return true;
        }

        if(element2Top>element1Top && element2Top<element1Bottom) {
            return true;
        }
        if(element2Bottom>element1Top && element2Bottom<element1Bottom){
            return true;
        }

        return overlap;
    };

    calculateEventPosition = function(eventStartTime, eventEndTime) {
        var startHours = eventStartTime.getHours(),
            startMinutes = eventStartTime.getMinutes(),
            startThirtyMinuteMark,
            startPosition,
            timeDistance,
            endPosition,
            endThirtyMinuteMark,
            endHours = eventEndTime.getHours(),
            endMinutes = eventEndTime.getMinutes(),
            startHourPosition,
            endHourPosition;

       if(startMinutes === 30) {
           startHourPosition = $('div[data-time=' + startHours + '30]').position();
           startThirtyMinuteMark = startHourPosition;
           startMinutes = 0; // We have an exact time start, don't need to worry about start mins anymore
       } else if (startMinutes > 30) {
           startHourPosition = $('div[data-time=' + (startHours) + '30]').position();
           startThirtyMinuteMark = $('div[data-time=' + (startHours + 1) + '00]').position();
       } else if(startMinutes < 30 && startMinutes > 0) {
           startHourPosition = $('div[data-time=' + startHours + '00]').position();
           startThirtyMinuteMark = $('div[data-time=' + startHours + '30]').position();
           startMinutes += 30;
       } else {
           startHourPosition = $('div[data-time=' + startHours + '00]').position();
           startThirtyMinuteMark = startHourPosition;
       }

       timeDistance = startThirtyMinuteMark.top - startHourPosition.top;
       startPosition = startHourPosition.top + Math.abs(startMinutes - timeDistance);


       if(endMinutes === 30) {
           endHourPosition = $('div[data-time=' + endHours + '30]').position();
           endThirtyMinuteMark = endHourPosition;
           endMinutes = 0; // We have an exact time end, don't need to worry about end mins anymore
       } else if (endMinutes > 30) {
           endHourPosition = $('div[data-time=' + (endHours) + '30]').position();
           endThirtyMinuteMark = $('div[data-time=' + (endHours + 1) + '00]').position();
       } else if(endMinutes < 30 && endMinutes > 0) {
           endHourPosition = $('div[data-time=' + endHours + '00]').position();
           endThirtyMinuteMark = $('div[data-time=' + endHours + '30]').position();
       } else {
           endHourPosition = $('div[data-time=' + endHours + '00]').position();
           endThirtyMinuteMark = endHourPosition;
       }

       timeDistance = endThirtyMinuteMark.top - endHourPosition.top;
       endPosition = endHourPosition.top + Math.abs(endMinutes - timeDistance);

       return {
           startPosition: startPosition,
           endHeight: endPosition - startPosition
       };

    };

    convertTimeStringToDate = function(timeString) {
        var hours,
            minutes,
            dateObj;

        if(timeString.length < 4) {
            timeString = '0' + timeString;
        }
        hours = +timeString.substr(0, 2);
        minutes = +timeString.substr(2,2);

        dateObj = new Date();
        dateObj.setHours(hours);
        dateObj.setMinutes(minutes);

        return dateObj;
    };

    generateEvent = function(eventObject) {
        numEvents++;
        return Mustache.render(eventTemplate, {
            eventId: numEvents,
            startTime: eventObject.start,
            endTime: eventObject.end
        });

    };

    convertMinutesToHoursAndMinutes = function(minutes) {
        var numHours,
            numMinutes;

        if(minutes >= 60) {
            numHours = Math.floor(minutes / 60);
            numMinutes = minutes % 60;
        } else {
            numHours = 0;
            numMinutes = minutes;
        }

        return {
            hours: numHours,
            minutes: numMinutes
        };
    };

    C = function(events, config) {
        var i,
            numEvents = events.length - 1;

        config = config || {};

        this.config = {
            dayStartTime: config.dayStartTime || '900',
            dayEndTime: config.dayEndTime || '2100'
        };
        this.config.dayStartDate = convertTimeStringToDate(this.config.dayStartTime);
        this.config.dayEndDate = convertTimeStringToDate(this.config.dayEndTime);

        this.events = events;
        for(i = 0; i <= numEvents; i++) {
            this.placeEvent(events[i]);
        }

    };
    C.prototype = {
        constructor: C,
        getEventStartAndEndTime: function(eventObj) {
            var eventStartHoursAndMinutes,
                eventEndHoursAndMinutes,
                baseStartDate = this.config.dayStartDate,
                baseEndDate = this.config.dayEndDate,
                eventStartDate = new Date(),
                eventEndDate = new Date();

            if(isNaN(+eventObj.start) === true || isNaN(+eventObj.end) === true) {
                throw new Exception("Unaelement2Lefte to get event position: event object start/stop time is invalid");
            }
            eventStartHoursAndMinutes = convertMinutesToHoursAndMinutes(eventObj.start);
            eventEndHoursAndMinutes = convertMinutesToHoursAndMinutes(eventObj.end);

            eventStartDate.setHours(baseStartDate.getHours() + eventStartHoursAndMinutes.hours);
            eventStartDate.setMinutes(baseStartDate.getMinutes() + eventStartHoursAndMinutes.minutes);

            eventEndDate.setHours(baseStartDate.getHours() + eventEndHoursAndMinutes.hours);
            eventEndDate.setMinutes(baseStartDate.getMinutes() + eventEndHoursAndMinutes.minutes);

            return {
                startTime: eventStartDate,
                endTime: eventEndDate
            };
        },
        placeEvent: function(event) {
            var eventStartAndEndTime = this.getEventStartAndEndTime(event),
                startDate = eventStartAndEndTime.startTime,
                endTime = eventStartAndEndTime.endTime,
                eventPosition = calculateEventPosition(eventStartAndEndTime.startTime, eventStartAndEndTime.endTime),
                eventHtml = $(generateEvent(event)),
                eventList = $('#event_list');

            console.log(eventStartAndEndTime);
            eventHtml.css({
                top: (eventPosition.startPosition) + 'px',
                height: (eventPosition.endHeight) + 'px'
            });

            eventHtml.appendTo(eventList);
            resizeEvents(eventHtml);
        }
    };

    return C;
}($));

