Day 1 2013-02-28 @ 19:27 to 19:58 (CST)
==============

The two main challenges that concern me about the project are:

Rendering the Whole Calendar Area
-----------------

The screenshot sent over with the puzzles requirements makes the project seem simpler than it really is. When I look closer at the image, I see two main areas:

1. The sidebar denoting full and half-hour increments
2. The main area containing the events.

My initial instincts say "Two column layout - float left". Unfortunately, they did not send over a style guide, so I'm going to have to guess as to how wide the far left column (I'll call this the "time" column) is going to be. I'm guessing that the best approach is going to be a percentage based one with the time column being the smallest and the event column being the remaining percentage from the time column (e.g., if the time column is 30% the event column would be
70%).

Style wise, I think I'll use CSS3 selectors to style the half-hour increments different from the hour increments. Maybe I can steal a page from all the row striping tutorials I've seen and use the ```nth-child(odd)``` selector to style every other time element (half hour increments):

```CSS
p:nth-child(odd) {
    /* Styling logic to make the text smaller */
}
```

The ```<p>``` tag referenced in the above example is purely for example. I don't have a clue what markup I'm going to use for layout yet.

Positioning the Events on the Calendar
-----------------

I can honestly say that this problem worries me more than the rendering of the calendar. My initial thoughts bounce between absolute positioning (which would work when position events on the hour, but would most likely go poorly when events overlap and need to be positioned side by side) and left floats (which could create a nightmare for the positioning of elements on the hour). Maybe I can pull together a hybrid approach?