<?php

global $k_option;


#########################################

if ( function_exists('register_sidebar') )
{	

		/*
		register_sidebar(array(
			'name' => 'Frontpage Sidebar',
			'before_widget' => '<div id="%1$s" class="box_small box widget %2$s">', 
		'after_widget' => '</div>', 
		'before_title' => '<h3 class="widgettitle">', 
		'after_title' => '</h3>', 
		));
		*/
		
		register_sidebar(array(
			'name' => 'Sidebar Blog',
			'before_widget' => '<div id="%1$s" class="box_small box widget %2$s">', 
		'after_widget' => '</div>', 
		'before_title' => '<h3 class="widgettitle">', 
		'after_title' => '</h3>', 
		));
	
		register_sidebar(array(
			'name' => 'Sidebar Pages',
			'before_widget' => '<div id="%1$s" class="box_small box widget %2$s">', 
		'after_widget' => '</div>', 
		'before_title' => '<h3 class="widgettitle">', 
		'after_title' => '</h3>', 
		));
		
		
		register_sidebar(array(
			'name' => 'Displayed Everywhere',
			'before_widget' => '<div id="%1$s" class="box_small box widget %2$s">', 
		'after_widget' => '</div>', 
		'before_title' => '<h3 class="widgettitle">', 
		'after_title' => '</h3>', 
		));
	

		
	$k_option['custom']['footer'] = array('column1','column2','column3','column4');

	foreach ($k_option['custom']['footer'] as $footer_widget)
	{
		register_sidebar(array(
		'name' => 'Footer - '.$footer_widget,
		'before_widget' => '<div id="%1$s" class="box_small box widget %2$s">', 
		'after_widget' => '</div>', 
		'before_title' => '<h3 class="widgettitle">', 
		'after_title' => '</h3>', 
		));
	}
	

	
	
		$dynamic_widgets = explode(',',$k_option['includes']['multi_widget_final']);
		foreach ($dynamic_widgets as $page_name)
		{	
		
			if($page_name != "")
			register_sidebar(array(
			'name' => 'Page: '.get_the_title($page_name),
			'before_widget' => '<div id="%1$s" class="box_small box widget %2$s">', 
			'after_widget' => '</div>', 
			'before_title' => '<h3 class="widgettitle">', 
			'after_title' => '</h3>', 
			));
		
	}
	
	
	
	$dynamic_widgets_cat = explode(',',$k_option['includes']['multi_widget_cat_final']);
	foreach ($dynamic_widgets_cat as $the_cat)
	{
	
		
			$the_cat_name = get_cat_name($the_cat);

			if($the_cat_name != "")
			register_sidebar(array(
			'name' => 'Category: '.$the_cat_name,
			'before_widget' => '<div id="%1$s" class="box_small box widget %2$s">', 
			'after_widget' => '</div>', 
			'before_title' => '<h3 class="widgettitle">', 
			'after_title' => '</h3>', 
			));
		
	}
}


	
	
	
	function dummy_widget($number)
	{
		switch($number)
		{
			case 1:  
				echo "<div class='widget widget_archive'>";
				echo "<h3 class='widgettitle'>Archive</h3>";
				echo "<ul>";
				wp_get_archives('type=monthly');
				echo "</ul>";
				echo "</div>";
			break;
			
			case 2: 
				echo "<div class='widget widget_archive'>";
				echo "<h3 class='widgettitle'>Categories</h3>";
				echo "<ul>";
				wp_list_cats('sort_column=name&optioncount=0&hierarchical=0');
				echo "</ul>";
				echo "</div>";
			break;
			
			case 3: 
				echo "<div class='widget widget_pages'>";
				echo "<h3 class='widgettitle'>Pages</h3>";
				echo "<ul>";
				wp_list_pages('title_li=&depth=-1' );
				echo "</ul>";
				echo "</div>";
			break;
			
			case 5: 
				echo "<h3 class='widgettitle'>Latest News</h3>";
				$sbNews = new Kriesi_sidebar_news_Widget();
				$sbNews->widget(array(),'');
			break;
			
			case 4:
				echo '<div class="widget community_news"><h3 class="widgettitle">Features</h3>		
						<div class="entry box_entry">
						<p><strong>Absolutley Striking Designs</strong><br/>Lorem ipsum dolor sit amet, usmod tempor incididunt ut labore et dolore magna aliqua.</p>
						</div>
					
						<div class="entry box_entry">
						<p><strong>Multiple color options</strong><br/>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
						</div>
						
						<div class="entry box_entry">
						<p><strong>Unique Features</strong><br/>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor. Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
						</div>
					
					<!--end box-->
					</div>';
			break;
		}
	}