<?php
 get_header(); 

?>
	
	<div class="wrapper" id='wrapper_main'>

	<div class="center">		
		
		<div id="main">
		
		
			
	
	<?php
	$counter = 1;
	
	if (have_posts()) :
	while (have_posts()) : the_post();	
 	$more = 1;
 	
	# get the feature image/video by calling the function in display_feature_media.php file, display it if its a Big Image/ Video 
 	# or save it to the var $medium_prev_image if its a small one to display it within the post, not above
 	$medium_prev_image = display_featured_media($counter);
 	
 	if( $counter == 1 ) echo "<div class='content'>";

	$terms = get_the_term_list( $post->ID, 'portfolio_entries', '', ', ', '' ); 
 	
	?>
	
	
<div class="entry <?php echo "entry".$counter; ?> entry_solo">
<?php if($medium_prev_image != "") echo $medium_prev_image; ?>
			
			<div class="date_container">
   				<span class='day'><?php the_time('d') ?></span>
   				<span class='month'><?php the_time('M') ?></span>
   				<span class='year'><?php the_time('Y') ?></span>
   				<?php if($k_option['single']['acc_tw'] != '') { ?>
   				<div class="tweetmeme">
					<script type="text/javascript"> 
						tweetmeme_source = '<?php echo $k_option['single']['acc_tw']; ?>'; 
						tweetmeme_url = '<?php echo get_permalink() ?>';
 					</script>
					<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
				</div>
				<?php } ?>
   				<span class='date_container_bottom'></span>
			</div><!-- end date -->
			
			<h1 class="siteheading">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link:','habitat')?> <?php the_title(); ?>"><?php the_title(); ?>
				</a>
			</h1>
			
			
			<div class="entry-head">
			    <span class="comments"><?php comments_popup_link(__('No Comments','habitat'), __('1 Comment','habitat'), __('% Comments','habitat')); ?></span>
			    <span class="categories"><?php the_category(', '); echo $terms; ?></span>					
			</div>
			
			
			<div class="entry-content">
			<?php 
			
			the_content('<span>'.__('Read more','habitat').'</span>'); ?>
			
			<span class="tag_list"><?php the_tags('<span class="the_tags">'.__('Tags: ','habitat').'</span>'); ?></span>
			<!--end entry-content-->
			</div>
<?php edit_post_link('Edit', '', ''); ?>
	 <!--end entry-->
	 </div>
 			<?php
		
		$counter++;
		
		endwhile;		
		else: 
		
			echo'<h2>'.__('Nothing Found','habitat').'</h2>';
			echo'<p>'.__('Sorry, no posts matched your criteria','habitat').'</p>';
			
		endif;
		?>
			
		
			<div class='entry <?php echo "entry_".$k_option['single']['social']."_".$k_option['single']['authorinfo']?>' id="post-meta-box">
				<div class='social-box'>
				<?php 
					
					   echo "<strong>";
					  _e('Enjoyed this Post?','habitat');
					  echo "</strong><br/>";
					  _e('Subscribe to our','habitat');
					  echo " <a href='";
					  bloginfo('rss2_url');
					  echo "'>RSS Feed</a>, ";
					  
					  if($k_option['single']['acc_tw'] != '') 
					  {
					  		_e('Follow us on ');
					  		echo "<a title ='' href='http://twitter.com/".$k_option['single']['acc_tw']."'>Twitter</a> ";
					  }
					  _e('or simply recommend us to friends and colleagues!','habitat');

				?>
					<div class='share_stuff'>
											    			
						<!-- AddToAny BEGIN -->
						<a class="a2a_dd" href="http://www.addtoany.com/share_save">Share this post</a>
						<script type="text/javascript" src="http://static.addtoany.com/menu/page.js"></script>
						<!-- AddToAny END -->
						
						<!-- Facebook add BEGIN -->
						<a class="fb_share" type="box_count" href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>">Share on facebook</a>
						<!-- Facebook add END -->				
					
					</div>
				
				</div>
			
			<div class='author-box'>
			
			    <div class="author-box-gravatar">
					<?php 
						$author_email = get_the_author_email();
				        echo get_avatar( $author_email, $size = '60');
					 	
					?>
				</div>
		    	<div class="author-info">
		        <strong><?php _e('written by ','habitat');?> <?php the_author_posts_link();?></strong><br/>
		        <?php 
		        $description = get_the_author_description(); 
		        if($description  != '')
		        {
		        	echo $description;
		        }
		        else
		        {
		        	_e('The author didn‘t add any Information to his profile yet.','habitat');
		        }
		        
		        ?> 
		    	</div> 
		    </div>
		   </div>
		   
		   
		   
		<?php // related posts
		$this_id = $post->ID;
		$tags = wp_get_post_tags($post->ID);
		if ($tags) {
		 
		     $tag_ids = "";
		     foreach ($tags as $tag ) $tag_ids .= $tag->name.",";
		     $tag_ids = substr_replace($tag_ids ,"",-1);
		     
		     if($tag_ids) 
		     {
		     	$my_query = new WP_Query("tag=$tag_ids&showposts=7&caller_get_posts=1&orderby=rand");
		     
		  		if ($my_query->have_posts()) 
		  		{ 
		  			$count = 0;
		  	
		     	$output  = "<div class='related_posts entry'>";
		     	$output .= "<strong class='heading'>Related Posts</strong><ul>";
		 
		     	while ($my_query->have_posts()) : $my_query->the_post(); 
		     	if($post->ID != $this_id && $count < 6)
		     	{	
		     		$small_prev = kriesi_featured_images($post->ID, array(	'size'=> 'S', 		  
 																'link' => 'none',
 																'style' => 'single',
 																'overwrite' => false)
 															);
		     		$output .= "<li class='relThumb ie6fix relThumb".($count+1)."'>\n";
					$output .= "<a href='".get_permalink()."' class='relThumWrap noLightbox'>\n";
					$output .= "<span class='relThumbTitle'>\n";
					$output .= "<strong class='relThumbHeading rounded ie6fix'>".get_the_title()."</strong>\n";
					$output .= "</span>\n";
					$output .= "<span class='blank_image'>?</span>";
					$output .= $small_prev."";
					$output .= "</a>";
					$output .= "</li><!-- end .relThumb -->\n";
		     		
		     		
		     		
		     		$count++;
		     	} 
		     	endwhile; 
		 
		     	$output .= " </ul></div>";
		     	if($count != 0) echo $output;
		 
		     		
		     	}
		     	wp_reset_query();
		      }
		 } 
 
 		 # comments
		echo " <div class='entry commententries'>";
        comments_template();
        echo "</div>";
        echo "	<div class='entry lastentry'>";
		echo "	</div>";
		echo "</div>";

	$k_option['showSidebar'] = 'blog';
	get_sidebar();
	?>
	<!--end main-->
		</div>
	<?php
	get_footer();
?>			

