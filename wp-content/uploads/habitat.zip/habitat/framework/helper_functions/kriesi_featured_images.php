<?php
######################################################################
# displays the featured images

# can either be used to display only the first featured image 
# (only as image, optionally within an <a> tag but without beeing wrapped in an <ul> )

# or can be used to put all featured images into an unordered list
# 
# params:
# style: false or "single" -> false displays all images as list, single will only output the fist image
# ul_attr, li_attr, link_attr: attributes that should be added to the list, the list items or the links
# size: S, M, L etc, defined at the top of the functions.php file. sets the image size that should be displayed
# lightbox size:default lightbox size, lightbox will display the image version that is closest to the passed dimenstions
#
# link: default values are : permalink, lightbox and none
# advanced stuff: 	you can also either pass the name of a custom field that starts with an "_" (underline) or that starts with "custom_"
#					the value of this field would be applied to each link then
#
#					you can also pass the word lightbox for example so that every image would open its bigger version in a lightbox
#					and in your wordpress post panel overwrite single value with the custom field 
#					"featured_link_1, featured_link_4, featured_link_5" etc
#
#
# title, caption alt tag etc are set when uploading the image in the wordpress backend. title will always overwrite alt tag to be the same.
# Caption and Description both feed the <a title=''> so the lightbox displays them when opening
#
# overwrite is enabled by default but for plugins like the latest news plugin it needs to be disabled
#


#dependencies: lots_of_small_helpers.php: kriesi_is_file
######################################################################


function kriesi_featured_images($this_post, $option)
{	
	global $k_option;
	
	$defaults = array(	'link'=>false,
						'lightboxSize' => array(800,800),
						'size'=>false,
						'ul_attr' => '',
						'li_attr' => array('class'=>"featured"),
						'link_attr' => array('title'=>""),
						'style' => false,
						'overwrite' => true
						);
	
	$option = array_merge((array)$defaults,(array)$option);
	$option['size'] = $k_option['custom']['imgSize'][$option['size']];
	
	
	//first we need to check how many featured images we got for this post
	$count = 1;
	$imageIds = array();
	
	while($count != false)
	{	
		#check if a featured image is set with id 1
		$result = get_post_meta($this_post, '_kriesi_featured_image'.$count, true);
		
		#if this is the first iteration and we didnt get a result check for the basic post thumbnail that might be set in another theme
		if(!$result && $count == 1) $result = get_post_meta($this_post, '_thumbnail_id', true);
		
		if($result != "")
		{
			$imageIds[] = $result;
			$count++;
		}
		else
		{
			$count = false;
		}
	}
	
	#if we got any results start the output loop
	if(isset($imageIds[0]))
	{
		//build defaults
		$link = array('open'=>"",'close'=>"");
		$featuredimages = $output = "";
		
		//build attribute strings for container and list items
		$ul_attr_string = kriesi_attribute_builder($option['ul_attr']);
		
		$ul['open'] = "<ul $ul_attr_string>";
		$ul['close'] = "</ul>";
		
		if($option['style'] == 'single')
		{
			$imageIds = array($imageIds[0]);
		}
		
		$count = 1;
		foreach ( $imageIds as $thumbnail_id )
		{
			#build the actual image:
			$attachment =& get_post($thumbnail_id);
			$custom_overwrite = "";

			$image_src = wp_get_attachment_image_src($thumbnail_id, array($option['size']['width'], $option['size']['height']));
			$image_title = $attachment->post_title;
			$image_description = $attachment->post_excerpt == "" ? $attachment->post_content : $attachment->post_excerpt;
			
			$image_title = trim(strip_tags($image_title));
			$image_description = trim(strip_tags($image_description));
			
			#create image description if available
			if($image_description != "")
			{
				$option['link_attr']['title'] = $image_description;
			}
			else
			{
				$option['link_attr']['title'] = "";
			}
			
			#create atributes for links
			$link_attr_string =  kriesi_attribute_builder($option['link_attr']);
			
			#create attributes for list items
			$option_mod['li_attr']['class'] = $option['li_attr']['class'] ." featured_container".$count; 
			$list_attr_string =  kriesi_attribute_builder($option_mod['li_attr']);
			
			$li['open'] = "<li $list_attr_string>";
			$li['close'] = "</li>";
			
			//if we only want to display a single image without list items remove the ul and li array and delete all images but one
			if($option['style'] == 'single')
			{
				$ul['open'] = $ul['close'] = $li['open'] = $li['close'] = '';
			}
			
			//check if the value was overwriten from the post backend
			$custom_overwrite = get_post_meta($this_post, "featured_link_".$count, true);
			
			if($option['link'] || $custom_overwrite != "")
			{
				$link['close'] = "</a>";
				
				if($custom_overwrite != "" && $option['overwrite'] == true)
				{
					$switchCheck = 'custom_overwrite';
				}
				else
				{
					$switchCheck = $option['link'];
				}
				
				//check which kind of link to apply
				switch($switchCheck)
				{
					case 'lightbox':
					 	$image_lb = wp_get_attachment_image_src($thumbnail_id, $option['lightboxSize']);
						$link['open'] = "<a $link_attr_string href='".$image_lb[0]."' rel='lightbox[group$this_post]'>";
					break;
					
					case 'permalink':
					 	$linkURL = get_permalink($this_post);
						$link['open'] = "<a $link_attr_string href='".$linkURL."'>";
					break;
					
					case 'none':
						$link['open'] = "<span $link_attr_string>";
						$link['close'] = "</span>";
					break;
					
					case 'custom_overwrite':
					 	$linkURL = $custom_overwrite;
					 	$lightboxCode = "";
					 	if(kriesi_is_file($linkURL, 'videoService') || kriesi_is_file($linkURL, 'image'))
					 	{
					 		$lightboxCode = "rel='lightbox[group$this_post]'";
					 	}
						$link['open'] = "<a $link_attr_string href='".$linkURL."' $lightboxCode>";
					break;
					
					case strpos($option['link'],"_") === 0 || strpos($option['link'],"custom_") === 0: 
						$linkURL = get_post_meta($this_post, $option['link'],true);
						$link['open'] = "<a href='".$linkURL."' $link_attr_string>";
					break;
				}
			}
			
			if($image_src) $final_image = "<img src='".$image_src[0]."' alt='$image_title' title='$image_title' />";
			
			if($final_image) $featuredimages .=$li['open'].$link['open'].$final_image.$link['close'].$li['close'];
		
			$count++;
		}
		
		if($featuredimages) $output = $ul['open'].$featuredimages.$ul['close'];
	}

	return $output;
}



function kriesi_attribute_builder($option)
{
	if(is_array($option))
	{	
		foreach ($option as $attr=>$value)
		{
			$attr_string .= $attr."='".$value."' ";
		}
		return $attr_string;
	}
}