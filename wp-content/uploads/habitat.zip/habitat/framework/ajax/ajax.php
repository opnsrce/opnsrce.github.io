<?php

    $paths = array(
        "../..",
        "../../..",
        "../../../..",
        "../../../../..",
        "../../../../../..",
        "../../../../../../..",
        "../../../../../../../.."
    );
   
   	#include wordpress, make sure its available in one of the higher folders
    foreach ($paths as $path) 
    {
       if(@include_once($path.'/wp-load.php')) break;
    }
    
# end request if no action was specified or user is not logged in
if ( ! isset( $_REQUEST['action'] ) || !function_exists('is_user_logged_in') || !is_user_logged_in()) die('-1');


$action = $_REQUEST['action'];

@header('Content-Type: text/html; charset=' . get_option('blog_charset'));
send_nosniff_header();



switch ($action)
{

	#backend single post/page/portfolio item: add multiple preview pictures. get a preview picture via ajax request and display it
	case 'multipostthumb':
	
	$attachment_id = (int) $_POST['attachment_id'];
	$output = wp_get_attachment_image($attachment_id, array(100,100));
	
	echo $output;
	
	break;
}