jQuery.noConflict();

jQuery(document).ready(function()
{	
	// these 2 statements change the labels in the uploader for the first time and then when something new is uploaded 
	kriesi_changelabels();
	jQuery(".slidetoggle").live('mouseenter',kriesi_changelabels);
});


//changes the labels of the media uploader to better reflect the current task
function kriesi_changelabels()
{
	var changeLabels = jQuery("meta[name=kriesi_change_labels]").attr('content'),
		changeLabelsadvanced = jQuery("meta[name=kriesi_change_labels_advanced]").attr('content');
		
	if(changeLabels == "true")
	{

		var savesendContainer = jQuery(".savesend"),
			insertInto = jQuery(".button", savesendContainer),
			useFeatured = jQuery(".wp-post-thumbnail", savesendContainer);
			
			if(changeLabelsadvanced == "true")
			{
				insertInto.val('Insert Image as additional Featured Image');
				useFeatured.css('display','none');	
				kriesi_multiple_featured_images();		
			}
			else
			{
				insertInto.val('Insert File');
				useFeatured.css('display','none');
			}
	}
}


//javascript needed for multiple featured images

function kriesi_multiple_featured_images()
{
	var savesendContainer = jQuery(".savesend"),
		insertInto = jQuery(".button", savesendContainer),
		ajaxUrl = jQuery("meta[name=kwf_ajax]").attr('content'),
		targetname =  jQuery("meta[name=hijack_target]").attr('content'),
		target = jQuery('input[name='+targetname+']', parent.document),
		imageTarget = jQuery("#"+targetname+"_div", parent.document);
	
	insertInto.unbind('click').bind('click', function()
	{
		var attachment_id = this.name.replace(/send\[/,"").replace(/\]/,"");
	
		jQuery.ajax({
 		  type: "POST",
 		  url: ajaxUrl,
 		  data: "action=multipostthumb&attachment_id="+attachment_id,
 		  success: function(msg)
 		  {
 		  
 		    imageTarget.html(msg);
 		  	target.val(attachment_id);
 		  	parent.tb_remove();
 		  }
 		});
 		
 		return false;
	});	
}










