<?php
/*
  Copyright 2010  Christian "Kriesi" Budschedl (office[at]kriesi.at)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


class kriesi_tweetbox extends WP_Widget {
	
	function kriesi_tweetbox() {
		//Constructor
		$widget_ops = array('classname' => 'tweetbox', 'description' => 'A widget to display your latest twitter messages' );
		$this->WP_Widget( 'tweetbox', THEMENAME.' Twitter Widget', $widget_ops );
	}

	function widget($args, $instance) {
		// prints the widget

		extract($args, EXTR_SKIP);
		echo $before_widget;
		
		$title = empty($instance['title']) ? '' : apply_filters('widget_title', $instance['title']);
		$count = empty($instance['count']) ? '' : apply_filters('widget_title', $instance['count']);
		$username = empty($instance['username']) ? '' : apply_filters('widget_title', $instance['username']);
		$exclude_replies = empty($instance['exclude_replies']) ? '' : apply_filters('widget_title', $instance['exclude_replies']);
		$time = empty($instance['time']) ? 'no' : apply_filters('widget_title', $instance['time']);
		$display_image = empty($instance['display_image']) ? 'no' : apply_filters('widget_title', $instance['display_image']);
		
		if ( !empty( $title ) ) { echo $before_title . "<a href='http://twitter.com/$username/' title='$title'>".$title ."</a>". $after_title; };
		
		$messages = tweetbox_get_tweet($count, $username, $widget_id, $time, $exclude_replies, $display_image);
		echo $messages;
		
		echo $after_widget;
		
		
	}

	function update($new_instance, $old_instance) {
		//save the widget		
		
		
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['count'] = strip_tags($new_instance['count']);
		$instance['username'] = strip_tags($new_instance['username']);
		$instance['exclude_replies'] = strip_tags($new_instance['exclude_replies']);
		$instance['time'] = strip_tags($new_instance['time']);
		$instance['display_image'] = strip_tags($new_instance['display_image']);
		
		delete_transient(THEMENAME.'_tweetcache_'.$instance['username'].'_'.$this->id_base."-".$this->number);
		return $instance;
	}

	function form($instance) {
		//widgetform in backend
		global $k_option;
		
		$instance = wp_parse_args( (array) $instance, array( 'title' => 'Latest Tweets', 'count' => '3', 'username' => $k_option['single']['acc_tw'] ) );
		$title = strip_tags($instance['title']);
		$count = strip_tags($instance['count']);
		$username = strip_tags($instance['username']);
		$exclude_replies = strip_tags($instance['exclude_replies']);
		$time = strip_tags($instance['time']);
		$display_image = strip_tags($instance['display_image']);
?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>">Title: 
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
		
		<p><label for="<?php echo $this->get_field_id('username'); ?>">Enter your twitter username:
		<input class="widefat" id="<?php echo $this->get_field_id('username'); ?>" name="<?php echo $this->get_field_name('username'); ?>" type="text" value="<?php echo attribute_escape($username); ?>" /></label></p>
		
		<p>
			<label for="<?php echo $this->get_field_id('count'); ?>">How many entries do you want to display: </label>
			<select class="widefat" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>">
				<?php 
				$list = "";
				for ($i = 1; $i <= 20; $i++ )
				{
					$selected = "";
					if($count == $i) $selected = 'selected="selected"';
				
					$list .= "<option $selected value='$i'>$i</option>";
				}
				$list .= "</select>";
				echo $list;
				?>
				
			
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('exclude_replies'); ?>">Exclude @replies: </label>
			<select class="widefat" id="<?php echo $this->get_field_id('exclude_replies'); ?>" name="<?php echo $this->get_field_name('exclude_replies'); ?>">
				<?php 
				$list = "";
				$answers = array('yes','no');
				foreach ($answers as $answer)
				{
					$selected = "";
					if($answer == $exclude_replies) $selected = 'selected="selected"';
				
					$list .= "<option $selected value='$answer'>$answer</option>";
				}
				$list .= "</select>";
				echo $list;
				?>
				
			
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('time'); ?>">Display time of tweet</label>
			<select class="widefat" id="<?php echo $this->get_field_id('time'); ?>" name="<?php echo $this->get_field_name('time'); ?>">
				<?php 
				$list = "";
				$answers = array('yes','no');
				foreach ($answers as $answer)
				{
					$selected = "";
					if($answer == $time) $selected = 'selected="selected"';
				
					$list .= "<option $selected value='$answer'>$answer</option>";
				}
				$list .= "</select>";
				echo $list;
				?>
				
			
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('display_image'); ?>">Display Twitter User Avatar</label>
			<select class="widefat" id="<?php echo $this->get_field_id('display_image'); ?>" name="<?php echo $this->get_field_name('display_image'); ?>">
				<?php 
				$list = "";
				$answers = array('yes','no');
				foreach ($answers as $answer)
				{
					$selected = "";
					if($answer == $display_image) $selected = 'selected="selected"';
				
					$list .= "<option $selected value='$answer'>$answer</option>";
				}
				$list .= "</select>";
				echo $list;
				?>
		</p>
		
		
		
	<?php	
	}
}

register_widget('kriesi_tweetbox');


function tweetbox_get_tweet($count, $username, $widget_id, $time='yes', $exclude_replies='yes', $avatar = 'yes')
{		
		$filtered_message = "";
		$output = "";
		$iterations = 0;
		
		$cache = get_transient(THEMENAME.'_tweetcache_'.$username.'_'.$widget_id);
		
		if($cache)
		{
			$tweets = $cache;
		}
		else
		{
			$response = wp_remote_get( 'http://api.twitter.com/1/statuses/user_timeline.xml?screen_name='.$username );
					
			if (!is_wp_error($response)) 
			{
				$xml = simplexml_load_string($response['body']);
				if( empty( $xml->error ) ) 
			    {
			    	if ( isset($xml->status[0])) 
			    	{
			    		
			    	    $tweets = array();
			    	    foreach ($xml->status as $tweet) 
			    	    {
			    	    	if($iterations == $count) break;
			    	    	
			    	    	$text = (string) $tweet->text;
			    	    	if($exclude_replies == 'no' || ($exclude_replies == 'yes' && $text[0] != "@"))
			    	    	{
			    	    		$iterations++;
			    	    		$tweets[] = array(
			    	    			'text' => tweetbox_filter( $text ),
			    	    			'created' =>  strtotime( $tweet->created_at ),
			    	    			'user' => array(
			    	    				'name' => (string)$tweet->user->name,
			    	    				'screen_name' => (string)$tweet->user->screen_name,
			    	    				'image' => (string)$tweet->user->profile_image_url
			    	    			));
			    			}
			    		}
			    		
			    		set_transient(THEMENAME.'_tweetcache_'.$username.'_'.$widget_id, $tweets, 60*30);
			    	}
			    }
			}
		}
		
	    if(isset($tweets[0]))
	    {		
	    	foreach ($tweets as $message)
	    	{	
	    		$output .= '<li class="tweet">';
	    		if($avatar == "yes") $output .= '<div class="tweet-thumb"><a href="http://twitter.com/'.$username.'" title=""><img src="'.$message['user']['image'].'" alt="" /></a></div>';
	    		$output .= '<div class="tweet-text avatar_'.$avatar.'">'.$message['text'];
	    		if($time == "yes") $output .= '<div class="tweet-time">'.date( get_option('date_format')." - ".get_option('time_format'),$message['created']).'</div>';
	    		$output .= '</div></li>';
			}
	    }
	
		
		if($output != "")
		{
			$filtered_message = "<ul class='tweets'>$image$output</ul>";
		}
		else
		{
			$filtered_message = "<ul class='tweets'><li>No public Tweets found</li></ul>";
		}
		
		return $filtered_message;
}


function tweetbox_filter($text) {
    // Props to Allen Shaw & webmancers.com & Michael Voigt
    $text = preg_replace('/\b([a-zA-Z]+:\/\/[\w_.\-]+\.[a-zA-Z]{2,6}[\/\w\-~.?=&%#+$*!]*)\b/i',"<a href=\"$1\" class=\"twitter-link\">$1</a>", $text);
    $text = preg_replace('/\b(?<!:\/\/)(www\.[\w_.\-]+\.[a-zA-Z]{2,6}[\/\w\-~.?=&%#+$*!]*)\b/i',"<a href=\"http://$1\" class=\"twitter-link\">$1</a>", $text);    
    $text = preg_replace("/\b([a-zA-Z][a-zA-Z0-9\_\.\-]*[a-zA-Z]*\@[a-zA-Z][a-zA-Z0-9\_\.\-]*[a-zA-Z]{2,6})\b/i","<a href=\"mailto://$1\" class=\"twitter-link\">$1</a>", $text);
    $text = preg_replace("/#(\w+)/", "<a class=\"twitter-link\" href=\"http://search.twitter.com/search?q=\\1\">#\\1</a>", $text);
    $text = preg_replace("/@(\w+)/", "<a class=\"twitter-link\" href=\"http://twitter.com/\\1\">@\\1</a>", $text);

    return $text;
}

?>