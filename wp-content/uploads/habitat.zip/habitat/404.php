<?php 
###########################################################################################

global $k_option;

######################################################################
# Display 404 Page
######################################################################
get_header();
?>
	<div class="wrapper" id='wrapper_main'>

	<div class="center">		
		
		<div id="main">
		<div class='content'>

 			<?php
			echo '<h2 class="superheading">Error 404 - Page not Found</h2>';
			echo'<div class="entry">';
			echo'<h2>'.__('Nothing Found','habitat').'</h2>';
			echo'<p>'.__('Sorry, no posts matched your criteria','habitat').'</p>';
			echo "</div>";
			echo "</div>";

	$k_option['showSidebar'] = 'page';
	get_sidebar();
	?>
	<!--end main-->
		</div>
	<?php
	get_footer();
?>