<?php
$pageinfo = array('full_name' => 'Mainpage Options', 'optionname'=>'mainpage', 'child'=>true, 'filename' => basename(__FILE__));

$options = array (

	array(	"type" => "open"),
	array(	"type" => "group"),
		

	
	     	array(	"name" => "Exclude Categories",
			"desc" => "The Mainpage Blog usually displays all categorys. Since sometimes you want to remove some of these categories you can EXCLUDE them here:",
            "id" => "main_cat",
            "type" => "multi",
            "subtype" => "cat"),  
		
	array(  "name" => "",
			"desc" => "Also remove those categories from category sidebar widgets?",
            "id" => "blog_widget_exclude",
            "type" => "radio",
            "buttons" => array('Yes','No'),
            "std" => 1),	

     array(	"type" => "group"),       
	array(	"type" => "close")


	
			
);

$options_page = new kriesi_option_pages($options, $pageinfo);
