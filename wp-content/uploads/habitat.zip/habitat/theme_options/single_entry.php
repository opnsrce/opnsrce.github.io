<?php
$pageinfo = array('full_name' => 'Single Entry Options', 'optionname'=>'single', 'child'=>true, 'filename' => basename(__FILE__));

$options = array (

	array(	"type" => "open"),
	array(	"type" => "group"),
		
 array(	"name" => "Social Media Share buttons",
			"desc" => "Display Social media links at the bottom of a post (located between post and comment section)?",
            "id" => "social",
            "type" => "dropdown",
            "std" => "social",
            "subtype" => array("yes"=>"social","no"=>"no_social")),
            
 array(	"name" => "Author Information",
			"desc" => "Display Author Information at the bottom of a post (located between post and comment section)?",
            "id" => "authorinfo",
            "type" => "dropdown",
            "std" => "authorinfo",
            "subtype" => array("yes"=>"authorinfo","no"=>"no_authorinfo")),
     
 
 array(	"name" => "Twitter Account",
			"desc" => "Enter the name of your twitter account to make the retweet button below the post date appear",
			"id" => "acc_tw",
			"std" => "",
			"size" => 20,
			"type" => "text"),           
            
     array(	"type" => "group"),       
	array(	"type" => "close")
	
	


	
			
);

$options_page = new kriesi_option_pages($options, $pageinfo);
