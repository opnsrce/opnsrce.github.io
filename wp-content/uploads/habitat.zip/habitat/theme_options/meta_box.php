<?php
global $k_option;



$options = array();
$boxinfo = array('title' => 'Featured Image additional Options', 'id'=>'post_thumb_overwrite', 'page'=>array('post','page','portfolio'), 'context'=>'side', 'priority'=>'low', 'callback'=>'');
		

$options[] = array(	"name" => "<strong>Use Video instead of Featured Images</strong>",
			"desc" => "You can enter the url to a video site here (youtube, vimeo, etc) and it will be directly embedded instead of any featured pictures.<br/> Example: <br/>
			http://vimeo.com/1084537
			",
			"id" => "_featured_video",
			"std" => "",
			"button_label" => "Insert Video Url",
			"size" => 31,
			"type" => "text");
			
$options[] =	array(	"name" => "<strong>Blog Overview Preview Images links</strong>",
	"desc" => "<br/>What should happen if a user clicks a featured Image?",
    "id" => "_overwrite_click",
    "type" => "dropdown",
    "std" => "",
    "subtype" => array('Default (set in Slideshow settings)'=>'','Open lightbox'=>'lightbox','Open single post view'=>'permalink','Nothing'=>'none'));			

$new_box = new kriesi_meta_box($options, $boxinfo);




$options = array();
$boxinfo = array('title' => 'Featured Images', 'id'=>'post_thumb_add', 'page'=>array('post','page','portfolio'), 'context'=>'side', 'priority'=>'low', 'callback'=>'');


$options[] = array(	"name" => "Add Featured Image?",
			"desc" => "Image",
			"id" => "_kriesi_featured_image1",
			"std" => "",
			"button_label" => "Insert Image",
			"size" => 31,
			"type" => "featured");


$new_box2 = new kriesi_meta_box($options, $boxinfo);

