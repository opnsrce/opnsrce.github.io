<?php 
global $k_option, $custom_widget_area;
if ($k_option['custom']['bodyclass'] == "") // check if its a full width page, if full width dont show the sidebar content
{
			##############################################################################
			# Display the sidebar menu
			##############################################################################

				$default_sidebar = true;
				
				echo "<div class='sidebar'>";
				echo "<span class='sidebar_top'><!-- needed for smooth start of sidebar background--></span>";
				echo "<span class='sidebar_bottom'><!-- needed for smooth end of sidebar background--></span>";
					
					
				//Frontpage sidebars:
/* 				if ($k_option['showSidebar'] == 'frontpage' && dynamic_sidebar('Frontpage Sidebar') ) : $default_sidebar = false; endif; */
				
				
				//unique Page sidebars:
				if (function_exists('dynamic_sidebar') && dynamic_sidebar('Page: '.$custom_widget_area) ) : $default_sidebar = false; endif;
				
				if(is_array($custom_widget_area))
				{
					foreach($custom_widget_area as $area)
					{
					//unique Category sidebars
					if (function_exists('dynamic_sidebar') && dynamic_sidebar('Category: '.$area) ) : $default_sidebar = false; endif;
					}
				}	
				
				if($default_sidebar != false)
				{
				// general blog sidebars
				if ($k_option['showSidebar'] == 'blog' && dynamic_sidebar('Sidebar Blog') ) : $default_sidebar = false; endif;
								
				// general pages sidebars
				if ($k_option['showSidebar'] == 'page' && dynamic_sidebar('Sidebar Pages') ) : $default_sidebar = false; endif;
				
				//sidebar area displayed everywhere
				if (function_exists('dynamic_sidebar') && dynamic_sidebar('Displayed Everywhere')) : $default_sidebar = false; endif;
				}
				
				
				
				
				//default dummy sidebar if no widgets are applied
				if ($default_sidebar && $k_option['includes']['dummy_sidebars'] == 1)
				{
					
					//the dummy placholding widgets called here are defined within the widgets.php file at the very bottom
					if(is_page())
					{
						dummy_widget(5);
						dummy_widget(1);
					}
					else
					{
						dummy_widget(1);
						dummy_widget(2);
						dummy_widget(3);
					}
				}
				echo "</div>";

}	       	?>	          