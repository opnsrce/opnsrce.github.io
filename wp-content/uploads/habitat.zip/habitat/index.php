<?php
 get_header(); 

	$negative_cats = preg_replace("!(\d)+!","-${0}$0", $k_option['mainpage']['main_cat_final']);
	$query_string = "cat=".$negative_cats."&paged=$paged";
	

	// the query string now looks like this:
	// "cat=-3,-10-12&paged=$paged";
	// you can add additional query options if you want, all of them are described here:
	// http://codex.wordpress.org/Template_Tags/query_posts#Examples
	// append this parameters with the "&" sign
	
	// example: $query_string =  $query_string."&orderby=author&order=ASC";
	?>
	
	<div class="wrapper" id='wrapper_main'>

	<div class="center">		
		
		<div id="main">
		
		
			
	
	<?php
	$additional_loop = new WP_Query($query_string);
	
	#counts the post iterations
	$counter = 1;

	if ($additional_loop->have_posts()) :
	while ($additional_loop->have_posts()) : $additional_loop->the_post();	
 	$more = 0;
 	
 	# get the feature image/video by calling the function in display_feature_media.php file, display it if its a Big Image/ Video 
 	# or save it to the var $medium_prev_image if its a small one to display it within the post, not above the post
 	$medium_prev_image = display_featured_media($counter);
 	
 	
 	if( $counter == 1 ) echo "<div class='content'>";
	?>
	
	
<div class="entry <?php echo "entry".$counter; ?> ">
<?php if($medium_prev_image != "") echo $medium_prev_image; ?>
			
			<div class="date_container">
   				<span class='day'><?php the_time('d') ?></span>
   				<span class='month'><?php the_time('M') ?></span>
   				<span class='year'><?php the_time('Y') ?></span>
   				<?php if($k_option['single']['acc_tw'] != '') { ?>
   				<div class="tweetmeme">
					<script type="text/javascript"> 
						tweetmeme_source = '<?php echo $k_option['single']['acc_tw']; ?>'; 
						tweetmeme_url = '<?php echo get_permalink() ?>';
 					</script>
					<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
				</div>
				<?php } ?>
   				<span class='date_container_bottom'></span>
			</div><!-- end date -->
			
			<h1 class="siteheading">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link:','habitat')?> <?php the_title(); ?>"><?php the_title(); ?>
				</a>
			</h1>
			
			
			<div class="entry-head">
			    <span class="comments"><?php comments_popup_link(__('No Comments','habitat'), __('1 Comment','habitat'), __('% Comments','habitat')); ?></span>
			    <span class="categories"><?php the_category(', '); ?></span>					
			</div>
			
			
			<div class="entry-content">
			<?php 
			
			the_content('<span>'.__('Read more','habitat').'</span>'); ?>
			<?php edit_post_link('Edit', '', ''); ?>
			<!--end entry-content-->
			</div>

	 <!--end entry-->
	 </div>
 			<?php
		
		$counter++;
		
		endwhile;		
		else: 
			echo'<div class="entry">';
			echo'<h2>'.__('Nothing Found','habitat').'</h2>';
			echo'<p>'.__('Sorry, no posts matched your criteria','habitat').'</p>';
			echo "</div>";
		endif;
		echo "	<div class='entry lastentry'>";
				kriesi_pagination($additional_loop->max_num_pages);
		echo "	</div>";
		echo "</div>";

	$k_option['showSidebar'] = 'blog';
	get_sidebar();
	?>
	<!--end main-->
		</div>
	<?php
	get_footer();
?>			

