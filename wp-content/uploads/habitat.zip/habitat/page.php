<?php 
###############################################################################################
# Check if the page displayed has a different template applied within the custom admin page
# if thats the case display the template file, otherwise display the basic page template
###############################################################################################

global $k_option;
######################################################################
# Check for blog and contact pages
######################################################################
if ($post->ID == $k_option['contact']['contact_page']) $contactpage = true;
else if ($post->ID == $k_option['blog']['blog_page']) $blogpage = true;


######################################################################
# Check for portfolio pages
######################################################################
if(isset($k_option['portfolio']['matrix_slider_port_final']) && $k_option['portfolio']['matrix_slider_port_final'] != ''){
	foreach($k_option['portfolio']['matrix_slider_port_final'] as $key => $value)
	{
		if ($post->ID == $key)
		{	
			$portfoliopage = true;
		} 
	}
}

######################################################################
# Include page templates if other template is applied to the page
######################################################################
if($contactpage)
{
	include(TEMPLATEPATH."/template_contact.php");
}
else if($blogpage)
{
	include(TEMPLATEPATH."/template_blog.php");
}
else if($portfoliopage)
{
	include(TEMPLATEPATH."/template_portfolio.php");
}
else
{

######################################################################
# Display Basic Page
######################################################################
get_header();
?>
	<div class="wrapper" id='wrapper_main'>

	<div class="center">		
		
		<div id="main">

	<?php
	$counter = 1;
	
	if (have_posts()) :
	while (have_posts()) : the_post();	
 	$more = 1;
 	
 	# get the feature image/video by calling the function in display_feature_media.php file, display it if its a Big Image/ Video 
 	# or save it to the var $medium_prev_image if its a small one to display it within the post, not above the post
 	$medium_prev_image = display_featured_media($counter);
 	
 	if( $counter == 1 ) echo "<div class='content'>";

 	
	?>
	
	
<div class="entry <?php echo "entry".$counter; ?> entry_solo">
<?php if($medium_prev_image != "") echo $medium_prev_image; ?>
			
			<!--
			##########################################################################################################
			If you want to display date and twitter counter on your pages as well uncomment the following lines:
			##########################################################################################################
			
			<div class="date_container">
   				<span class='day'><?php the_time('d') ?></span>
   				<span class='month'><?php the_time('M') ?></span>
   				<span class='year'><?php the_time('Y') ?></span>
   				<div class="tweetmeme">
					<script type="text/javascript"> 
						tweetmeme_source = '<?php echo $k_option['social']['twitter']; ?>'; 
						tweetmeme_url = '<?php echo get_permalink() ?>';
 					</script>
					<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
				</div>
   				<span class='date_container_bottom'></span>
			</div>
			
			 -->
			
			<h1 class="siteheading">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link:','habitat')?> <?php the_title(); ?>"><?php the_title(); ?>
				</a>
			</h1>
			
			<!--
			##################################################################################
			No comments and categories if on a page unless you uncomment the following lines:
			##################################################################################
			
			<div class="entry-head">
			    <span class="comments"><?php comments_popup_link(__('No Comments','habitat'), __('1 Comment','habitat'), __('% Comments','habitat')); ?></span>
			    <span class="categories"><?php the_category(', '); ?></span>					
			</div>
			-->
			
			<div class="entry-content">
			<?php 
			
			the_content('<span>'.__('Read more','habitat').'</span>'); ?>
			<?php edit_post_link('Edit', '', ''); ?>
			<!--end entry-content-->
			</div>

	 <!--end entry-->
	 </div>
 			<?php
		
		$counter++;
		
		endwhile;		
		else: 
			echo'<div class="entry">';
			echo'<h2>'.__('Nothing Found','habitat').'</h2>';
			echo'<p>'.__('Sorry, no posts matched your criteria','habitat').'</p>';
			echo "</div>";
		endif;
		echo "</div>";

	$k_option['showSidebar'] = 'page';
	get_sidebar();
	?>
	<!--end main-->
		</div>
	<?php
	get_footer();
 } ?>