<?php
/*
Template Name: Contact Form
*/
global $k_option;
$name_of_your_site = get_option('blogname');
$email_adress_reciever = $k_option['contact']['email'];

$errorC = true;
if(isset($_POST['Send']))
{
	include('send.php');	
}



get_header();
?>
	<div class="wrapper" id='wrapper_main'>

	<div class="center">		
		
		<div id="main">

	<?php
	$counter = 1;
	
	if (have_posts()) :
	while (have_posts()) : the_post();	
 	$more = 1;
 	
 	# get the feature image/video by calling the function in display_feature_media.php file, display it if its a Big Image/ Video 
 	# or save it to the var $medium_prev_image if its a small one to display it within the post, not above the post
 	$medium_prev_image = display_featured_media($counter);
 	
 	if( $counter == 1 ) echo "<div class='content'>";

 	
	?>
	
	
<div class="entry <?php echo "entry".$counter; ?> entry_solo">
<?php if($medium_prev_image != "") echo $medium_prev_image; ?>
			
			<!--
			##########################################################################################################
			If you want to display date and twitter counter on your pages as well uncomment the following lines:
			##########################################################################################################
			
			<div class="date_container">
   				<span class='day'><?php the_time('d') ?></span>
   				<span class='month'><?php the_time('M') ?></span>
   				<span class='year'><?php the_time('Y') ?></span>
   				<div class="tweetmeme">
					<script type="text/javascript"> 
						tweetmeme_source = '<?php echo $k_option['social']['twitter']; ?>'; 
						tweetmeme_url = '<?php echo get_permalink() ?>';
 					</script>
					<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
				</div>
   				<span class='date_container_bottom'></span>
			</div>
			
			 -->
			
			<h1 class="siteheading">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link:','habitat')?> <?php the_title(); ?>"><?php the_title(); ?>
				</a>
			</h1>
			
			<!--
			##################################################################################
			No comments and categories if on a page unless you uncomment the following lines:
			##################################################################################
			
			<div class="entry-head">
			    <span class="comments"><?php comments_popup_link(__('No Comments','habitat'), __('1 Comment','habitat'), __('% Comments','habitat')); ?></span>
			    <span class="categories"><?php the_category(', '); ?></span>					
			</div>
			-->
			
			<div class="entry-content">
			<?php 
			
			the_content('<span>'.__('Read more','habitat').'</span>'); ?>
			<form action="" method="post" class="ajax_form">
						<fieldset><?php if (!isset($errorC) || $errorC == true){ ?><h3><span><?php _e('Send us mail','habitat'); ?></span></h3>
						
						<p class="<?php if (isset($the_nameclass)) echo $the_nameclass; ?>" ><input name="yourname" class="text_input is_empty" type="text" id="name" size="20" value='<?php if (isset($the_name)) echo $the_name?>'/><label for="name"><?php _e('Your Name','habitat'); ?>*</label>
						</p>
						<p class="<?php if (isset($the_emailclass)) echo $the_emailclass; ?>" ><input name="email" class="text_input is_email" type="text" id="email" size="20" value='<?php if (isset($the_email)) echo $the_email ?>' /><label for="email"><?php _e('E-Mail','habitat'); ?>*</label></p>
						<p><input name="website" class="text_input" type="text" id="website" size="20" value="<?php if (isset($the_website))  echo $the_website?>"/><label for="website"><?php _e('Website','habitat'); ?></label></p>
						<label for="message" class="blocklabel"><?php _e('Your Message','habitat'); ?>*</label>
						<p class="<?php if (isset($the_messageclass)) echo $the_messageclass; ?>"><textarea name="message" class="text_area is_empty" cols="40" rows="7" id="message" ><?php  if (isset($the_message)) echo $the_message ?></textarea>
						<input name="username" value="" id="username" class="username"/>
						</p>
						
						
						<p>
						
						<input type="hidden" id="myemail" name="myemail" value="<?php echo $email_adress_reciever; ?>" />
						<input type="hidden" id="myblogname" name="myblogname" value='<?php echo $name_of_your_site; ?>' />
						
						<input name="Send" type="submit" value="<?php _e('Send','habitat'); ?>" class="button" id="send" size="16"/></p>
						<?php } else { ?> 
						<p><h3><?php _e('Your message has been sent!','habitat'); ?> </h3> <?php _e('Thank you!','habitat'); ?> </p>
						
						<?php } ?>
						</fieldset>
					</form>
			<?php edit_post_link('Edit', '', ''); ?>
			<!--end entry-content-->
			</div>

	 <!--end entry-->
	 </div>
 			<?php
		
		$counter++;
		
		endwhile;		
		else: 
		
			echo'<h2>'.__('Nothing Found','habitat').'</h2>';
			echo'<p>'.__('Sorry, no posts matched your criteria','habitat').'</p>';
			
		endif;
		echo "</div>";

	$k_option['showSidebar'] = 'page';
	get_sidebar();
	?>
	<!--end main-->
		</div>
	<?php
	get_footer();
 ?>