<?php
function display_featured_media($counter, $the_size = "")
{
	global $post, $k_option;
	$big_prev_image = '';
 	
 	#check if the default size should be overwritten for this post
 	$overwrite_size = get_post_meta($post->ID, "_overwrite_size", true);
 	if($overwrite_size == 'firstBig' || $the_size == 'big') {$k_option['slideshow']['featured_layout'] = "firstBig";} else
 	if($overwrite_size == 'firstSmall' || $the_size == 'small') {$k_option['slideshow']['featured_layout'] = "";}
 	
 	 #controll how to handle click events for the slideshow images
 	 $linking_behaviour = $k_option['slideshow']['overview_image'];
 	 if(is_singular())
 	 {
 	 	$linking_behaviour = $k_option['slideshow']['overview_image_single'];
 	 }
 	 
 	 
 	$overwrite_click_event = get_post_meta($post->ID, "_overwrite_click", true);
 	if($overwrite_click_event) $linking_behaviour = $overwrite_click_event; 	
 	 	
 	#first check if a video should be displayed, if thats not the case display Images if available
 	$featured_video = get_featured_media('XL');
 	
    if($counter == 1 && $k_option['slideshow']['featured_layout'] == 'firstBig')
    {	
    	if($featured_video)
 		{
 			$big_prev_image = "<div class='slideshowBigVideo'>".$featured_video."</div>";
 		}
 		else
 		{
    	 //get full sized preview image for the first post, inject it before the actual post so it displays above the sidebar as well
    		$big_prev_image =kriesi_featured_images($post->ID, 
    												array(	'size'=> 'XL', 		  
    														'link' => $linking_behaviour,
    														'ul_attr'=>array('class'=>'slideshow slideshowBig featured_container'.$counter)
    													  ));	
    	}
    	echo $big_prev_image;
    }
    else
    {
    	if($featured_video)
 		{
 			$medium_prev_image = get_featured_media('L');
 		}
 		else
 		{
    	 //get medium sized preview images for all following posts
    	$medium_prev_image = kriesi_featured_images($post->ID, array(	'size'=> 'L', 		  
    																'link' => $linking_behaviour,
    																'ul_attr'=>array('class'=>'slideshow featured_container'.$counter))
																);
		}
		
		return $medium_prev_image;
    }
 }	
 	
?>