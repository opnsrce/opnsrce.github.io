<?php

/* If this is a category archive */ 
$output = "";
$useTemplate ="";
if (is_category()) { 		
$output = __('Archive for ','habitat').single_cat_title('',false);
} elseif (is_day()) {
$output = __('Archive for ','habitat').get_the_time('F jS, Y');
} elseif (is_month()){ 
$output = __('Archive for ','habitat').get_the_time('F, Y'); 
} elseif (is_year()) { 
$output = __('Archive for ','habitat').get_the_time('Y'); 
} elseif (is_search()) {
$output = __('Search Results','habitat'); 
} elseif (is_author()) { 
$output = __('Author Archive','habitat'); 
} elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {
$output = __('Blog Archives','habitat');
} elseif(is_tax()){
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
$output = __('Archive for ','habitat').$term->name;
$useTemplate = $term->slug;
}
 
if($output != "") $output = '<h2 class="superheading">'.$output.'</h2>';
		
if($useTemplate != '')
{
	include(TEMPLATEPATH."/template_portfolio.php");
}
else
{		
 get_header(); 

	?>
	
	<div class="wrapper" id='wrapper_main'>

	<div class="center">		
		
		<div id="main">
		
		<div class='content'>
			
	
	<?php
	$counter = 1;
	
	echo $output;
	
	if (have_posts()) :
	while ( have_posts()) :  the_post();	
 	$more = 0;
 	
 	# get the feature image/video by calling the function in display_feature_media.php file. 
 	# archive pages always display the small version
 	$medium_prev_image = display_featured_media($counter, 'small');

	?>
	
	
<div class="entry <?php echo "entry".$counter; ?> ">
<?php if($medium_prev_image != "") echo $medium_prev_image; ?>
			
			<div class="date_container">
   				<span class='day'><?php the_time('d') ?></span>
   				<span class='month'><?php the_time('M') ?></span>
   				<span class='year'><?php the_time('Y') ?></span>
   				<?php if($k_option['single']['acc_tw'] != '') { ?>
   				<div class="tweetmeme">
					<script type="text/javascript"> 
						tweetmeme_source = '<?php echo $k_option['single']['acc_tw']; ?>'; 
						tweetmeme_url = '<?php echo get_permalink() ?>';
 					</script>
					<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
				</div>
				<?php } ?>
   				<span class='date_container_bottom'></span>
			</div><!-- end date -->
			
			<h1 class="siteheading">
				<a href="<?php echo get_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link:','habitat')?> <?php the_title(); ?>"><?php the_title(); ?>
				</a>
			</h1>
			
			
			<div class="entry-head">
			    <span class="comments"><?php comments_popup_link(__('No Comments','habitat'), __('1 Comment','habitat'), __('% Comments','habitat')); ?></span>
			    <span class="categories"><?php the_category(', '); ?></span>					
			</div>
			
			
			<div class="entry-content">
			<?php 
			
			the_content('<span>'.__('Read more','habitat').'</span>'); ?>
			<?php edit_post_link('Edit', '', ''); ?>
			<!--end entry-content-->
			</div>

	 <!--end entry-->
	 </div>
 			<?php
		
		$counter++;
		
		endwhile;		
		else: 
		
			echo'<div class="entry">';
			echo'<h2>'.__('Nothing Found','habitat').'</h2>';
			echo'<p>'.__('Sorry, no posts matched your criteria','habitat').'</p>';
			echo "</div>";
			
		endif;
		echo "	<div class='entry lastentry'>";
				kriesi_pagination();
		echo "	</div>";
		echo "</div>";

	$k_option['showSidebar'] = 'blog';
	get_sidebar();
	?>
	<!--end main-->
		</div>
	<?php
	get_footer();			

}
?>			

